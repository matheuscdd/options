# Essential Dark Theme - Ulauncher
A theme for Ulauncher. Essential Dark Theme.

![CSS3](https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white)
![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)

## Screenshot
![](Screenshot_2022-04-24_19-03-05.png)

## Installation
```sh
mkdir -p ~/.config/ulauncher/user-themes
git clone https://github.com/GiorgioReale/Ulauncher-Essential-Dark-Theme.git \
  ~/.config/ulauncher/user-themes/Essential-Dark-Theme
```
### Light Theme:
[Essential Light Theme](https://github.com/GiorgioReale/Ulauncher-Essential-Light-Theme)
